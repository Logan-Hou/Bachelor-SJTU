leg.col <- c("red","orange","yellow","green","blue")
leg.txt <- c(expression(phantom() >= "99% confidence"),
             "95-99% confidence","90-95% confidence","80-90% confidence",
             expression(paste(phantom() < "80% confidence")))
par(las=1,mar=c(4,8,2,2),cex=1)
x <- read.table(file="C:\\Users\\Administrator\\Desktop\\2023校内赛\\问题二\\A6\\A6_imp.txt",header=TRUE)
score <- x$Score; vars <- x$Variable; type <- x$Type
barcol <- rep(leg.col[1],length(vars))
barcol[type == "B"] <- leg.col[2]
barcol[type == "C"] <- leg.col[3]
barcol[type == "D"] <- leg.col[4]
barcol[type == "E"] <- leg.col[5]
n <- 20  ### plot only top n important variables ###
barplot(rev(score[1:n]),names.arg=rev(vars[1:n]),
        col=rev(barcol[1:n]),horiz=TRUE,xlab="GUIDE importance scores")
legend("bottomright",legend=leg.txt,fill=leg.col)