z <- read.table("C:\\Users\\Administrator\\Desktop\\2023校内赛\\问题二\\A3\\transfered_fill_forrun.csv",
              header = TRUE,comment.char = '',encoding="UTF-8",sep=",")
k <- ncol(z)
write("transfered_fill_forrun.csv",file="C:\\Users\\Administrator\\Desktop\\2023校内赛\\问题二\\A3\\dsc_A3.txt")
write("NA",file="C:\\Users\\Administrator\\Desktop\\2023校内赛\\问题二\\A3\\dsc_A3.txt",append=TRUE)
write("2",file="C:\\Users\\Administrator\\Desktop\\2023校内赛\\问题二\\A3\\dsc_A3.txt",append=TRUE)

vartype <- rep('n',k)
vartype[names(z) %in% c('B2','B3','B4','B5','B6','B8','C4','C5','C7',
                        'C8','C10','C11','C16','C17')] <- "x"  #ignorance before eating

# first step : cover eating
vartype[61:263] <- "x"

vartype[names(z) %in% c('B1','B7','C1','C3','C6','C9','C12','C15',
                        'D23','D30','D37','D44','D51','D58','D65','D72','D79','D86',
                        'D93','D100','D107','D114','D121','D128','D135','D142','D149',
                        'D156','D163','D170','D1Z77',
                        'D184','D191','D198','D205',
                        'E1','E2','E3','E4')] <- "c"
vartype[275:309] <- "x"  # F开头的
vartype[1:8] <- "x"  # A开头的
vartype[names(z) == 'A3'] <- "d"
write.table(cbind(1:k,names(z),vartype),file="C:\\Users\\Administrator\\Desktop\\2023校内赛\\问题二\\A3\\dsc_A3.txt",
            append=TRUE,col.names=FALSE,row.names=FALSE,
            quote=FALSE)
